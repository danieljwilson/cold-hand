import { RectModel } from './series';

export type ZoomModels = { selectionArea: RectModel[] };
